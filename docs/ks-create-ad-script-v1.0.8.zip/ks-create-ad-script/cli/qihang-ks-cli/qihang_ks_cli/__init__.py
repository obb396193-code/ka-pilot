"""Qihang Kuaishou CLI package."""

__version__ = "1.0.1"

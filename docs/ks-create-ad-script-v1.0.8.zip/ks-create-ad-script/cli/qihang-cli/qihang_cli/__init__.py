"""Qihang OpenAPI CLI package."""

__version__ = "1.0.10"
